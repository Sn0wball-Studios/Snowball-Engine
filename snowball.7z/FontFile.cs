namespace Snowball
{
    public class FontFile
    {
        public string ttf = "";
        public uint size;
        public string uniqueName = "demoFont";
        public byte r = 255, g = 255, b = 255;
    }
}