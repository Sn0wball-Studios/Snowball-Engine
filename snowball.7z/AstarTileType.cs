namespace Snowball
{
    public enum AstarTileType
    {
        empty,
        wall,
        
    }
}