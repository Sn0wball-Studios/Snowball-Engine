using System.Numerics;
namespace Snowball
{
    public static class Astar
    {
        public const int TileEmpty = 0;
        public static int[,] map;
        public static int width, height;

        //TODO:
    }
}