switch = require("switchstatement")
local levelloader = {}

function levelloader:load_level(level)

end


return levelloader