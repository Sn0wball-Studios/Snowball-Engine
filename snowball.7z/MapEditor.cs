namespace Snowball
{
    public static class MapEditor
    {
    }
}