namespace Snowball
{
    public class EngineConfig
    {
        public string name = "";
        public string engineDLL = "";
        public string soundFactory = "";
        public string soundSource = "";
        public string window = "";

    }
}