namespace Snowball
{
    public static class MapLoader
    {
    
    }
}