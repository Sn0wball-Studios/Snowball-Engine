using System.Collections.Generic;
namespace Snowball
{
    public sealed class Prefab
    {
        public uint editorID;
        public string luaScript;
        public string editorGraphic = "editor/debug.json";
        
        
    }
}