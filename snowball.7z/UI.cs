namespace Snowball
{
    public static class UI
    {
        
    }
}