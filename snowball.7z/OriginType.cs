namespace Snowball
{
    public enum OriginType
    {
        topLeft,
        topCenter,
        topRight,
        centerLeft,
        centerCenter,
        centerRight,
        bottomLeft,
        bottomCenter,
        bottomRight
    }
}